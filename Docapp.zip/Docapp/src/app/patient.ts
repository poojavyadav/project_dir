export class Patient{
    firstName:string;
    lastName:string;
    age:number;
    gender:string;
    userName:string;
    password:string;
    email:string;

}